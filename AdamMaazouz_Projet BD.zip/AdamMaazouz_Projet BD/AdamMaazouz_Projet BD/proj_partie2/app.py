import sqlite3
import streamlit as st
from datetime import date

# Connexion à la base
conn = sqlite3.connect('hotel.db')
c = conn.cursor()

st.set_page_config(page_title="Gestion Hôtel", layout="wide")
st.title("📋 Interface de gestion hôtelière")

menu = ["Accueil", "Voir les clients", "Voir les réservations", "Chambres disponibles", "Ajouter un client", "Ajouter une réservation"]
choix = st.sidebar.selectbox("Navigation", menu)

if choix == "Voir les clients":
    st.subheader("Liste des clients")
    c.execute("SELECT * FROM Client")
    rows = c.fetchall()
    st.table(rows)

elif choix == "Voir les réservations":
    st.subheader("Liste des réservations")
    query = """
    SELECT R.Id_Reservation, R.Date_arrivee, R.Date_depart, C.Nom_complet, H.Ville
    FROM Reservation R
    JOIN Client C 
    JOIN reservation 
    JOIN Hotel H ; 
    """
    c.execute(query)
    rows = c.fetchall()
    st.table(rows)

elif choix == "Chambres disponibles":
    st.subheader("Chambres disponibles pendant une période")
    d1 = st.date_input("Date d'arrivée", value=date(2025, 6, 1))
    d2 = st.date_input("Date de départ", value=date(2025, 6, 30))
    if d1 < d2:
        query = f"""
        select id_chambre from chambre
        join reservation R
        where R.Date_arrivee <= '{d2}' AND R.Date_depart >= '{d1}'
        """
        c.execute(query)
        rows = c.fetchall()
        st.table(rows)
    else:
        st.warning("⚠️ La date de départ doit être postérieure à la date d'arrivée.")

elif choix == "Ajouter un client":
    st.subheader("Ajouter un nouveau client")
    nom = st.text_input("Nom complet")
    adresse = st.text_input("Adresse")
    ville = st.text_input("Ville")
    code_postal = st.text_input("Code postal")
    email = st.text_input("Email")
    telephone = st.text_input("Téléphone")
    if st.button("Enregistrer"):
        c.execute("INSERT INTO Client (Adresse, Ville, Code_postal, Email, Telephone, Nom_complet) VALUES (?, ?, ?, ?, ?, ?)",
                  (adresse, ville, code_postal, email, telephone, nom))
        conn.commit()
        st.success("✅ Client ajouté avec succès")

elif choix == "Ajouter une réservation":
    st.subheader("Ajouter une réservation")
    c.execute("SELECT Nom_complet FROM Client")
    clients = [row[0] for row in c.fetchall()]  # transforme liste de tuples en liste de noms
    client_nom = st.text_input("Nom du client (existant ou nouveau)")
    d1 = st.date_input("Date d'arrivée")
    d2 = st.date_input("Date de départ")
    if st.button("Réserver"):
        c.execute("INSERT INTO Reservation (Date_arrivee, Date_depart, Nom_complet) VALUES (?, ?, ?)",
                  (d1, d2, client_map[client_nom]))
        conn.commit()
        st.success("✅ Réservation enregistrée")

else:
    st.info("Bienvenue dans le système de gestion des hôtels.")