import sqlite3

# Connexion à la base de données (ou création si elle n'existe pas)
conn = sqlite3.connect('hotel.db')
c = conn.cursor()

# Création des tables
c.execute("""
CREATE TABLE IF NOT EXISTS Hotel (
    Id_Hotel numeric,
    Ville CHAR(20),
    Pays CHAR(20),
    Code_postal numeric,
    constraint pk_Hotel primary key (Id_Hotel)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Client (
    Nom_complet VARCHAR(50),
    Adresse VARCHAR(50),
    Ville VARCHAR(50),
    Code_postal numeric,
    Email VARCHAR(50),
    Telephone VARCHAR(20),
    constraint pk_Client primary key (Nom_complet)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Prestation (
    Id_Prestation numeric,
    Prix numeric(6,2),
    come_with VARCHAR(50),
    constraint pk_prestation primary key (Id_Prestation)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Type_Chambre (
    Id_Type numeric,
    Type VARCHAR(50),
    Tarif DECIMAL(6,2),
    constraint pk_Type_Chambre primary key (Id_Type)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Chambre (
    Id_Chambre numeric,
    Etage numeric,
    Fumeurs binary(256),
    Id_Hotel numeric,
    Id_Type numeric,
    constraint pk_chambre primary key (Id_Chambre),
    constraint fk_chambre_hotel foreign key (Id_Hotel) references Hotel(Id_Hotel),
    constraint fk_chambre_type foreign key (Id_Type) references Type_Chambre(Id_Type)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Reservation (
    Id_Reservation numeric,
    Date_arrivee DATE,
    Date_depart DATE,
    Nom_complet VARCHAR(50),
    constraint pk_reservation primary key (Id_Reservation),
    constraint fk_reservation foreign key (Nom_complet) references client(Nom_complet)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS Evaluation (
    Id_Evaluation numeric,
    date_arrivee DATE,
    Note numeric,
    texte_descriptif varchar(100),
    Id_Hotel numeric,
    Nom_complet VARCHAR(50),
    constraint pk_evaluation primary key (Id_Evaluation),
    constraint fk_evaluation_hotel foreign key (Id_Hotel) references hotel(Id_Hotel),
    constraint fk_evaluation_client foreign key (Nom_complet) references client(Nom_complet)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS offre (
    Id_Hotel numeric,
    Id_Prestation numeric,
    constraint pk_offre primary key (Id_Hotel, Id_Prestation),
    constraint fk_offre_hotel foreign key (Id_Hotel) references hotel(Id_Hotel),
    constraint fk_offre_prestation foreign key (Id_Prestation) references prestation(Id_Prestation)
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS concerner (
    Id_Reservation numeric,
    Id_Type numeric,
    constraint pk_concerner primary key (Id_Reservation, Id_Type),
    constraint fk_concerner_reservation foreign key (Id_Reservation) references reservation(Id_Reservation),
    constraint fk_concerner_type foreign key (Id_Type) references type_chambre(Id_Type)
);
""")

# Insertion des données
c.execute("INSERT INTO Chambre VALUES (201, 2, 0, 1, 1)")
c.execute("INSERT INTO Chambre VALUES (502, 5, 1, 1, 2)")
c.execute("INSERT INTO Chambre VALUES (305, 3, 0, 2, 1)")
c.execute("INSERT INTO Chambre VALUES (410, 4, 0, 2, 2)")
c.execute("INSERT INTO Chambre VALUES (104, 1, 1, 2, 2)")
c.execute("INSERT INTO Chambre VALUES (202, 2, 0, 1, 1)")
c.execute("INSERT INTO Chambre VALUES (307, 3, 1, 1, 2)")
c.execute("INSERT INTO Chambre VALUES (101, 1, 0, 1, 1)")
c.execute("INSERT INTO Client VALUES ('Jean Dupont','12 Rue de Paris', 'Paris', 75001, 'jean.dupont@email.fr', '0612345678')")
c.execute("INSERT INTO Client VALUES ('Marie Leroy','5 Avenue Victor Hugo', 'Lyon', 69002, 'marie.leroy@email.fr', '0623456789')")
c.execute("INSERT INTO Client VALUES ('Paul Moreau','8 Boulevard Saint-Michel', 'Marseille', 13005, 'paul.moreau@email.fr', '0634567890')")
c.execute("INSERT INTO Client VALUES ('Lucie Martin','27 Rue Nationale', 'Lille', 59800, 'lucie.martin@email.fr', '0645678901')")
c.execute("INSERT INTO Client VALUES ('Emma Giraud','3 Rue des Fleurs', 'Nice', 06000, 'emma.giraud@email.fr', '0656789012')")
c.execute("INSERT INTO Evaluation VALUES (1, '2025-06-15', 5, 'Excellent séjour, personnel très accueillant.', 1,'Jean Dupont')")
c.execute("INSERT INTO Evaluation VALUES (2, '2025-07-01', 4, 'Chambre propre, bon rapport qualité/prix.', 2, 'Marie Leroy')")
c.execute("INSERT INTO Evaluation VALUES (3, '2025-08-10', 3, 'Séjour correct mais bruyant la nuit.', 1, 'Paul Moreau')")
c.execute("INSERT INTO Evaluation VALUES (4, '2025-09-05', 5, 'Service impeccable, je recommande.',2, 'Lucie Martin' )")
c.execute("INSERT INTO Evaluation VALUES (5, '2025-09-20', 4, 'Très bon petit-déjeuner, hôtel bien situé.', 1, 'Emma Giraud')")
c.execute("INSERT INTO Hotel VALUES (1, 'Paris', 'France', 75001)")
c.execute("INSERT INTO Hotel VALUES (2, 'Lyon', 'France', 69002)")
c.execute("INSERT INTO Prestation VALUES (1, 15, 'Petit-déjeuner')")
c.execute("INSERT INTO Prestation VALUES (2, 30, 'Navette aéroport')")
c.execute("INSERT INTO Prestation VALUES (3, 0, 'Wi-Fi gratuit')")
c.execute("INSERT INTO Prestation VALUES (4, 50, 'Spa et bien-être')")
c.execute("INSERT INTO Prestation VALUES (5, 20, 'Parking sécurisé')")
c.execute("INSERT INTO Reservation VALUES (1, '2025-06-15', '2025-06-18', 'Jean Dupont')")
c.execute("INSERT INTO Reservation VALUES (2, '2025-07-01', '2025-07-05', 'Marie Leroy')")
c.execute("INSERT INTO Reservation VALUES (3, '2025-08-10', '2025-08-14', 'Paul Moreau')")
c.execute("INSERT INTO Reservation VALUES (4, '2025-09-05', '2025-09-07', 'Lucie Martin')")
c.execute("INSERT INTO Reservation VALUES (5, '2025-09-20', '2025-09-25', 'Emma Giraud')")
c.execute("INSERT INTO Reservation VALUES (7, '2025-11-12', '2025-11-14', 'Marie Leroy')")
c.execute("INSERT INTO Reservation VALUES (9, '2026-01-15', '2026-01-18', 'Lucie Martin')")
c.execute("INSERT INTO Reservation VALUES (10, '2026-02-01', '2026-02-05', 'Marie Leroy')")
c.execute("INSERT INTO Type_Chambre VALUES (1, 'Simple', 80)")
c.execute("INSERT INTO Type_Chambre VALUES (2, 'Double', 120)")

# Sauvegarde et fermeture
conn.commit()
conn.close()
