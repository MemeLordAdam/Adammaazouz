CREATE TABLE Hotel (
    Id_Hotel numeric,
    Ville CHAR(20),
    Pays CHAR(20),
    Code_postal numeric,
    constraint pk_Hotel primary key (Id_Hotel)
);

CREATE TABLE Client (
	Nom_complet VARCHAR(50),
    Adresse VARCHAR(50),
    Ville VARCHAR(50),
    Code_postal numeric,
    Email VARCHAR(50),
    Telephone VARCHAR(20),
    constraint pk_Client primary key (Nom_complet)
);

CREATE TABLE Type_Chambre (
    Id_Type numeric,
    Type VARCHAR(50),
    Tarif DECIMAL(6,2),
    constraint pk_Type_Chambre primary key (Id_Type)
);
CREATE TABLE Chambre (
    Id_Chambre numeric,
    Etage numeric,
    Fumeurs binary(256),
    Id_Hotel numeric,
    Id_Type numeric,
    constraint pk_chambre primary key (Id_Chambre),
    constraint fk_chambre_hotel foreign key (Id_Hotel) references Hotel(Id_Hotel),
    constraint fk_chambre_type foreign key (Id_Type) references Type_Chambre(Id_Type)
);

CREATE TABLE Prestation (
    Id_Prestation numeric,
    Prix numeric(6,2),
    come_with VARCHAR(50), --j'ai ajouté cette colonne pour la connecter a l'annexe donner dans l'exercice.
    constraint pk_prestation primary key (Id_Prestation)
);

CREATE TABLE Evaluation (
    Id_Evaluation numeric,
    date_arrivee DATE,
    Note numeric,
    texte_descriptif varchar(100),
    Id_Hotel numeric,
    Nom_complet VARCHAR(50),
    constraint pk_evaluation primary key (Id_Evaluation),
    constraint fk_evaluation_hotel foreign key (Id_Hotel) references hotel(Id_Hotel),
    constraint fk_evaluation_client foreign key (Nom_complet) references client(Nom_complet)
);

CREATE TABLE Reservation (
    Id_Reservation numeric,
    Date_arrivee DATE,
    Date_depart DATE,
    Nom_complet VARCHAR(50),
    constraint pk_reservation primary key (Id_Reservation),
    constraint fk_reservation foreign key (Nom_complet) references client(Nom_complet)
);

CREATE TABLE offre (
    Id_Hotel numeric,
    Id_Prestation numeric,
    constraint pk_offre primary key (Id_Hotel, Id_Prestation),
    constraint fk_offre_hotel foreign key (Id_Hotel) references hotel(Id_Hotel),
    constraint fk_offre_prestation foreign key (Id_Prestation) references prestation(Id_Prestation)
);

CREATE TABLE concerner (
    Id_Reservation numeric,
    Id_Type numeric,
    constraint pk_concerner primary key (Id_Reservation, Id_Type),
    constraint fk_concerner_reservation foreign key (Id_Reservation) references reservation(Id_Reservation),
    constraint fk_concerner_type foreign key (Id_Type) references type_chambre(Id_Type)
);

--LES REQUETES SQL :

-- a. Afficher les réservations avec nom du client et ville de l’hôtel
SELECT R.Id_Reservation, R.Date_arrivee, R.Date_depart, C.Nom_complet, H.Ville
FROM Reservation R
JOIN Client C 
JOIN reservation 
JOIN Hotel H ; 

-- b. Clients qui habitent à Paris
SELECT nom_complet FROM Client WHERE Ville = 'Paris';

-- c. Nombre de réservations par client
SELECT C.Nom_complet, COUNT(R.Id_Reservation)
FROM Client C
LEFT JOIN Reservation R ON C.Nom_complet = R.Nom_complet
GROUP BY C.Nom_complet;

-- d. Nombre de chambres par type de chambre
SELECT T.Type, COUNT(C.Id_type)
FROM Type_Chambre T
LEFT JOIN Chambre C ON T.Id_Type = C.Id_Type
GROUP BY T.Id_Type;

-- e. Chambres non réservées pour une période donnée (ex: '2025-06-01' à '2025-06-30')
select id_chambre from chambre
join reservation R
where R.Date_arrivee <= '2025-06-30' AND R.Date_depart >= '2025-06-01'
